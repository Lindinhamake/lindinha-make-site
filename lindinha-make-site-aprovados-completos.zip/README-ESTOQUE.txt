# Controle de estoque (Esgotado automático)

Agora o site aceita o campo `stock` em cada produto no products.json.

- Se `stock` for um número e estiver 0 (ou menor), o produto aparece como **ESGOTADO**
  e o botão do WhatsApp fica desativado.
- Se `stock` não existir, o produto fica normal (como antes).

Exemplo:
{
  "name": "Blush Jelly",
  "price": 12.00,
  "category": "MAQUIAGEM",
  "image": "assets/images/blush_jelly.png",
  "stock": 3
}

Quando acabar:
"stock": 0

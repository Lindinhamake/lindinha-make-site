# Site Catálogo — Lindinha Make (Estilo Bege/Chique)

Este pacote é um site simples (HTML/CSS/JS) com:
- Menu com ícones (Produtos, Novidades, Promoções, Envios, Avaliações)
- Grade (mosaico) 2x2 no topo igual ao estilo do exemplo
- Catálogo com preços + botão do WhatsApp em cada produto
- Busca + filtro por categoria

## 1) Colocar seu número do WhatsApp
Abra o arquivo **app.js** e troque:
const WHATSAPP_NUMBER = "55SEUDDDSEUNUMERO";

Exemplo:
- SP: 5511999999999
- RJ: 5521999999999

## 2) Trocar as imagens do topo (mosaico)
Arquivos:
assets/images/hero_welcome.jpg
assets/images/hero_1.jpg
assets/images/hero_2.jpg
assets/images/hero_video.jpg

Pode substituir por fotos suas, mantendo o mesmo nome.

## 3) Trocar produtos / preços / fotos
Abra **products.json** e edite:
- name (nome)
- price (preço)
- old_price (opcional)
- category (categoria)
- badge (opcional)
- whatsapp_message (mensagem opcional)
- image (caminho da foto)

Fotos dos produtos: coloque em assets/images/ e aponte no campo image.

## 4) Importante (fotos não cortam)
As imagens dos produtos estão com object-fit: contain, então não cortam e ficam com fundo branco.

## 5) Publicar (grátis)
Recomendado: Netlify (arrastar a pasta).

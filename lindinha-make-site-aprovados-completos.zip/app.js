// Lindinha Make — catálogo com preços + WhatsApp
// 1) Coloque seu número abaixo (com DDI). Ex: 55 + DDD + número
const WHATSAPP_NUMBER = "5511993412386"; // <- TROQUE AQUI (ex: "5511999999999")

// 2) Texto padrão (se o produto não tiver whatsapp_message no products.json)
const DEFAULT_MESSAGE = "Olá, vim pelo site da Lindinha Make 💄✨\nTenho interesse em um produto do catálogo. Pode me ajudar?";

const grid = document.getElementById("grid");
const searchInput = document.getElementById("search");
const categorySelect = document.getElementById("category");
const resultCount = document.getElementById("resultCount");
const empty = document.getElementById("empty");
const year = document.getElementById("year");
const whatsTop = document.getElementById("whatsTop");

year.textContent = new Date().getFullYear();

function makeWhatsLink(message){
  const text = encodeURIComponent(message || DEFAULT_MESSAGE);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
}

whatsTop.href = makeWhatsLink("Olá, vim pelo site da Lindinha Make 💄✨");

let allProducts = [];

function formatBRL(value){
  try{
    return value.toLocaleString("pt-BR", { style:"currency", currency:"BRL" });
  }catch{
    return "R$ " + String(value);
  }
}

function cardTemplate(p){
  const isOut = (typeof p.stock === "number") && (p.stock <= 0);
  const badgeText = isOut ? "ESGOTADO" : (p.badge || "");
  const badge = badgeText ? `<span class="badge ${isOut ? "badge--out" : ""}">${badgeText}</span>` : "";
  const old = p.old_price ? `<span class="old">${formatBRL(p.old_price)}</span>` : "";
  const msg = p.whatsapp_message || `Oi! Tenho interesse no produto: ${p.name}.`;
  const link = makeWhatsLink(msg);

  const btn = isOut
    ? `<span class="btn btn--disabled" aria-disabled="true">Esgotado</span>`
    : `<a class="btn" href="${link}" target="_blank" rel="noopener">Comprar no WhatsApp</a>`;

  return `
  <article class="product ${isOut ? "product--out" : ""}">
    <div class="product__img">
      <img src="${p.image}" alt="${p.name}" loading="lazy" />
    </div>
    <div class="product__body">
      <div class="product__top">
        <div>
          <div class="product__name">${p.name}</div>
          <div class="category">${p.category || "Produto"}</div>
        </div>
        ${badge}
      </div>

      <div class="priceRow">
        <div class="price">${formatBRL(p.price)}</div>
        ${old}
      </div>

      ${btn}
    </div>
  </article>
  `;
}

function render(list){
  grid.innerHTML = list.map(cardTemplate).join("");
  resultCount.textContent = `${list.length} produto(s)`;
  empty.classList.toggle("hidden", list.length !== 0);
}

function fillCategories(products){
  const cats = Array.from(new Set(products.map(p => p.category).filter(Boolean))).sort((a,b)=>a.localeCompare(b,"pt-BR"));
  const opts = ['<option value="all">Todas as categorias</option>']
    .concat(cats.map(c => `<option value="${c}">${c}</option>`));
  categorySelect.innerHTML = opts.join("");
}

function applyFilters(){
  const q = (searchInput.value || "").trim().toLowerCase();
  const cat = categorySelect.value;

  const filtered = allProducts.filter(p=>{
    const inCat = (cat === "all") || (p.category === cat);
    const inText = !q || (p.name || "").toLowerCase().includes(q) || (p.category || "").toLowerCase().includes(q);
    return inCat && inText;
  });

  render(filtered);
}

async function init(){
  try{
    const res = await fetch("products.json", { cache: "no-store" });
    allProducts = await res.json();
    fillCategories(allProducts);
    render(allProducts);
  }catch(err){
    console.error(err);
    resultCount.textContent = "Erro ao carregar produtos.";
  }

  searchInput.addEventListener("input", applyFilters);
  categorySelect.addEventListener("change", applyFilters);
}

init();
